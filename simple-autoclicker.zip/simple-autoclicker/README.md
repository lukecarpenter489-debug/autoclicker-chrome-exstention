# Simple Autoclicker Chrome Extension

A small Manifest V3 Chrome extension that clicks the element beneath your mouse pointer 10 times per second. Choose one keyboard key to start clicking and another to stop.

## Install from the ZIP

1. Download `simple-autoclicker.zip`.
2. Unzip it:
   - **Windows:** right-click the ZIP and choose **Extract All**.
   - **macOS:** double-click the ZIP.
3. In Chrome, open `chrome://extensions` (or open the ⋮ menu → **Extensions** → **Manage Extensions**).
4. Turn on **Developer mode** in the top-right corner.
5. Click **Load unpacked**.
6. Select the unzipped `simple-autoclicker` folder—the folder containing `manifest.json`.

Chrome does not load an unpacked extension directly from a ZIP, so it must be unzipped first.

## Use it

1. Open a normal webpage and refresh it once after installing the extension.
2. Click the extension's toolbar icon. You may need to open the puzzle-piece menu and pin **Simple Autoclicker** first.
3. Click the **Start key** box, then press the key you want. Do the same for **Stop key**. The defaults are **F6** and **F7**.
4. Move your mouse over the spot you want to click.
5. Press your start key to begin and your stop key to end.

You can also use the **Start** and **Stop** buttons in the popup. The extension works on regular `http://` and `https://` pages. Chrome blocks extensions from operating on protected pages such as `chrome://extensions` and the Chrome Web Store.

## Upload to GitHub

1. Create a new empty repository on GitHub (for example, `simple-autoclicker`).
2. Open a terminal inside the unzipped project folder.
3. Run:

```bash
git init
git add .
git commit -m "Initial Simple Autoclicker extension"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/simple-autoclicker.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. Do not commit the generated ZIP inside this folder; GitHub users can download the repository as a ZIP from the **Code** button.

## Files

- `manifest.json` — extension configuration
- `popup.html`, `popup.css`, `popup.js` — small settings popup
- `content.js` — key handling and clicking logic

## Privacy

This extension has no analytics, no network requests, and no data collection. It stores only the two selected keys in Chrome's synced extension storage.

## License

MIT
