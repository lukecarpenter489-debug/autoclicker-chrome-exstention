const DEFAULTS = {
  startKey: { code: "F6", label: "F6" },
  stopKey: { code: "F7", label: "F7" }
};

const startKeyButton = document.querySelector("#startKey");
const stopKeyButton = document.querySelector("#stopKey");
const message = document.querySelector("#message");
let settings = structuredClone(DEFAULTS);
let listeningFor = null;

function keyLabel(event) {
  if (event.code === "Space") return "Space";
  if (event.code.startsWith("Key")) return event.code.slice(3);
  if (event.code.startsWith("Digit")) return event.code.slice(5);
  return event.key.length === 1 ? event.key.toUpperCase() : event.key;
}

function render() {
  startKeyButton.textContent = settings.startKey.label;
  stopKeyButton.textContent = settings.stopKey.label;
  startKeyButton.classList.toggle("listening", listeningFor === "startKey");
  stopKeyButton.classList.toggle("listening", listeningFor === "stopKey");
}

async function loadSettings() {
  const saved = await chrome.storage.sync.get(DEFAULTS);
  settings = {
    startKey: saved.startKey,
    stopKey: saved.stopKey
  };
  render();
}

function listenForKey(settingName) {
  listeningFor = settingName;
  message.textContent = "Press the key you want to use…";
  render();
}

async function sendAction(action) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab?.id || !/^https?:/.test(tab.url || "")) {
    message.textContent = "Open a normal website first.";
    return;
  }

  try {
    await chrome.tabs.sendMessage(tab.id, { type: "AUTOCLICKER_ACTION", action });
    message.textContent = action === "start" ? "Clicking started." : "Clicking stopped.";
  } catch {
    message.textContent = "Refresh this page, then try again.";
  }
}

startKeyButton.addEventListener("click", () => listenForKey("startKey"));
stopKeyButton.addEventListener("click", () => listenForKey("stopKey"));
document.querySelector("#start").addEventListener("click", () => sendAction("start"));
document.querySelector("#stop").addEventListener("click", () => sendAction("stop"));

document.addEventListener("keydown", async (event) => {
  if (!listeningFor) return;

  event.preventDefault();
  event.stopPropagation();

  const otherSetting = listeningFor === "startKey" ? "stopKey" : "startKey";
  if (event.code === settings[otherSetting].code) {
    message.textContent = "Start and stop must use different keys.";
    return;
  }

  settings[listeningFor] = { code: event.code, label: keyLabel(event) };
  await chrome.storage.sync.set({ [listeningFor]: settings[listeningFor] });
  listeningFor = null;
  message.textContent = "Key saved automatically.";
  render();
}, true);

loadSettings();
