const DEFAULTS = {
  startKey: { code: "F6", label: "F6" },
  stopKey: { code: "F7", label: "F7" }
};

const CLICK_INTERVAL_MS = 100;
let settings = structuredClone(DEFAULTS);
let clickTimer = null;
let pointer = null;

chrome.storage.sync.get(DEFAULTS).then((saved) => {
  settings = saved;
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "sync") return;
  if (changes.startKey) settings.startKey = changes.startKey.newValue;
  if (changes.stopKey) settings.stopKey = changes.stopKey.newValue;
});

document.addEventListener("mousemove", (event) => {
  pointer = { x: event.clientX, y: event.clientY };
}, { passive: true });

function clickAtPointer() {
  if (!pointer) return;
  const target = document.elementFromPoint(pointer.x, pointer.y);
  if (target instanceof HTMLElement || target instanceof SVGElement) {
    target.click();
  }
}

function startClicking() {
  if (clickTimer || !pointer) return;
  clickAtPointer();
  clickTimer = window.setInterval(clickAtPointer, CLICK_INTERVAL_MS);
}

function stopClicking() {
  if (!clickTimer) return;
  window.clearInterval(clickTimer);
  clickTimer = null;
}

document.addEventListener("keydown", (event) => {
  if (event.repeat) return;

  if (event.code === settings.startKey.code) {
    event.preventDefault();
    startClicking();
  } else if (event.code === settings.stopKey.code) {
    event.preventDefault();
    stopClicking();
  }
}, true);

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "AUTOCLICKER_ACTION") return;
  if (message.action === "start") startClicking();
  if (message.action === "stop") stopClicking();
});

window.addEventListener("blur", stopClicking);
